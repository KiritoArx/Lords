﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lords_API.pointers
{
    public static class Pointers
    {
        public static int user = 0x02E1C890;
        public static int resouces = 0x02F067C0;
        public static int watchTower = 0x02DFDCE8;
        public static int colisium = 0x02DF8000;
        public static int barracks = 0x02E1E8C0;
    }
}
